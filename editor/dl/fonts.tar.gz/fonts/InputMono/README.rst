Input Mono
==========

Input Mono is officially supported by the font creator, with custom drawn glyphs
for Powerline. Download the font from http://input.fontbureau.com/!
