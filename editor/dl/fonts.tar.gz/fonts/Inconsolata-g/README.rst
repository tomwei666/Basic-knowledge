Inconsolata for Powerline
=========================

:Font creator: Ralph Levien (modified by Leonardo Maffi)
:Source: http://leonardo-m.livejournal.com/77079.html
:Patched by: `PaBLoX_CL <https://github.com/PaBLoX-CL>`_
