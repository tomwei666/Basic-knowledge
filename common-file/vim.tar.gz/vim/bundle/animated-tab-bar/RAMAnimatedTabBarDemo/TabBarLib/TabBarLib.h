//
//  TabBarLib.h
//  TabBarLib
//
//  Created by Alex K. on 14/10/16.
//  Copyright © 2016 Ramotion. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TabBarLib.
FOUNDATION_EXPORT double TabBarLibVersionNumber;

//! Project version string for TabBarLib.
FOUNDATION_EXPORT const unsigned char TabBarLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TabBarLib/PublicHeader.h>


