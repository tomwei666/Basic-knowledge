//
//  AnimatedTabBar.h
//  AnimatedTabBar
//
//  Created by Alex K. on 02/06/16.
//  Copyright © 2016 Ramotion. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AnimatedTabBar.
FOUNDATION_EXPORT double AnimatedTabBarVersionNumber;

//! Project version string for AnimatedTabBar.
FOUNDATION_EXPORT const unsigned char AnimatedTabBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnimatedTabBar/PublicHeader.h>


